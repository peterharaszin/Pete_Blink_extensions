console.log("Jira customizations by Pete initializing.");
/**
 * Workaround for the behavior on Jira "Hitting Escape key while editing issue description loses contents" 
 * @see https://jira.atlassian.com/browse/JRA-36670
 */
var ESCAPE_CHAR_CODE = 27;
var editingSelectorsToCheck = [
    "#create-issue-dialog", // when the Create Issue form is active
    "#edit-issue-dialog", // when the Edit Issue form is active
    ".editable-field.active" // when any form fields are active
];

// http://patorjk.com/software/taag/#p=display&f=Graffiti&t=JIRA%20mod%20by%20Pete
var consoleString = "%c\n"+
"      ____._____________    _____                       .___ ___.           __________        __            \n"+
"     |    |   \\______   \\  /  _  \\     _____   ____   __| _/ \\_ |__ ___.__. \\______   \\ _____/  |_  ____    \n"+
"     |    |   ||       _/ /  /_\\  \\   /     \\ /  _ \\ / __ |   | __ <   |  |  |     ___// __ \\   __\\/ __ \\   \n "+
"/\\__|    |   ||    |   \\/    |    \\ |  Y Y  (  <_> ) /_/ |   | \\_\\ \\___  |  |    |   \\  ___/|  | \\  ___/   \n"+
" \\________|___||____|_  /\\____|__  / |__|_|  /\\____/\\____ |   |___  / ____|  |____|    \\___  >__|  \\___  >  \n"+
"                     \\/         \\/        \\/            \\/       \\/\\/                     \\/          \\/   \n"+
"";

console.log(consoleString, "color: blue; font-size: medium; font-family: 'Courier New', Courier, 'Lucida Sans Typewriter', 'Lucida Typewriter', monospace; background-image:url('http://jira.alm.mentorg.com:8080/s/en_US-dpgxbf/6340/7/_/jira-logo-scaled.png');background-size:contain;background-repeat:no-repeat;background-position:center;");

var $document = $(document);

function isAnyEditorFieldActive() {
    for (var i = 0; i < editingSelectorsToCheck.length; i++) {
		var $editorField = $(editingSelectorsToCheck[i]);
        if ($editorField.length > 0 && $editorField.is(":visible")) {
            return true;
        }
    }
    return false;
}

$document.keydown(function(e) {
    //console.log("keydown")
    var charCode = e.charCode || e.keyCode || e.which;
    if (charCode == ESCAPE_CHAR_CODE && isAnyEditorFieldActive()) {
        // it seems like e.preventDefault() or e.stopPropagation() or returning false is not enough, we have to pop up an alert box to really stop propagation
		// BUT it does NOT work for popped up dialogs like when clicking "Create Issue"
        alert("Escape key's default behavior has been disabled.");
		return false;
    }
});
$document.keyup(function(e) {
    //console.log("keyup")
    var charCode = e.charCode || e.keyCode || e.which;
    if (charCode == ESCAPE_CHAR_CODE && isAnyEditorFieldActive()) {
		// it seems like e.preventDefault() or e.stopPropagation() or returning false is not enough, we have to pop up an alert box to really stop propagation
		// BUT it does NOT work for popped up dialogs like when clicking "Create Issue"
        alert("Escape key's default behavior has been disabled.");
        return false;
    }
});

// if any editor fields are active, let's confirm leaving the page (refreshing or closing the tab)
window.onbeforeunload = function() {
    if (isAnyEditorFieldActive()) {
        return "You are editing a field, do you really want to cancel it?";
    }
};

// move the Description field between the custom fields
function moveDescriptionFieldToBeginningOfCustomFields() {
	var isIssue = $('#issue-content').length !== 0;
	var $customFieldsList = $('#customfieldmodule .property-list');

	if(!isIssue || $customFieldsList.length === 0) {
		return;
	}

	var $descriptionFieldListItem = $('<li>', {
		"id": "description-field",
		"class": "item"
	});

	var $descriptionFieldWrap = $('<div>', {
		"id": "description-field-wrap",
		"class": "wrap"
	});

	var $title = $('<strong>', {
		"id": "description-field-title",
		"class": "name",
		"text": "Description"
	});

	//var $stepsToReproduceField = $('#rowForcustomfield_14168')
	//$stepsToReproduceField.before($descriptionFieldListItem);
	var $descriptionFieldDiv = $('#description-val');
	$customFieldsList.prepend($descriptionFieldListItem);
	$descriptionFieldListItem.append($descriptionFieldWrap);
	$descriptionFieldWrap.append($title);
	$title.after($descriptionFieldDiv);
	$('#descriptionmodule').remove();
}

$(document).ready(function() {
    console.log("Jira customizations by Pete (ready event occurred).");
	moveDescriptionFieldToBeginningOfCustomFields();
});